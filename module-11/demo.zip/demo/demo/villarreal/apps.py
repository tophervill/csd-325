from django.apps import AppConfig


class VillarrealConfig(AppConfig):
    name = 'villarreal'
